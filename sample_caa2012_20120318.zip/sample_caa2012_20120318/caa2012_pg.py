#!/usr/bin/python
# -*- coding: utf-8
# Import modules
import sys, os
import grass.script as g
from progressbar import * 

# Append python path to the "mygrass.py" & "pgwrapper.py".
# You need to configre path setting depending on your environment.
sys.path.append('/path/to/the/python/modules')

# Import cutom wrappers.
import mygrass
import rwrapper as r
from pgwrapper import pgwrapper as pg

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Constant
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# You need to configre connection parameters depending on your environment.
pgsql_name = "miyagi"
pgsql_srid = 2452
pgsql_user = "username"
pgsql_pass = "password"

grassdb_host = 'host=localhost,dbname=caa2012'
grassdb_type = "pg"
grassdb_user = "username"
grassdb_pass = "password"

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# General functions
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Conect to PostgreSQL database.
def connectToPgsql(dbname,srid,user,password):
	db = pg(dbname=dbname,srid=pgsql_srid,user=user,passwd=password)
	return db

# Conect to GRASS database and login to it.
def connectToGrassDb(dbhost,dbtype,user,password):
	g.run_command("db.connect",database=grassdb_host) 
	g.run_command("db.login",driver=dbtype,database=dbhost,user=user,password=password)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 1: Add columns to the "sites" table.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_1(dbInstance):
	print 'Add culumns to store variable...'
	table = "sites"		# Name of the table adding columns to.
	pgcol_nkey = "n_key"	# Name of the column for storing the identifier to the nearest feature.
	pgcol_ndist = "n_dist"	# Name of the column for storing the distance to the nearest feature.
	dbInstance.addcol(table, pgcol_ndist, "numeric")	# Add a new column for the nearest ids.
	dbInstance.addcol(table, pgcol_nkey, "integer")		# Add a new column for the nearest distances.
	dbInstance.connection.commit()				# Commit the changes.

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 2: Export points to the GRASS GIS vector map.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_2(dbInstance,dbhost,dbtype,user,password):
	# Connect and login to GRASS database.
	connectToGrassDb(dbhost, dbtype, user, password)
	# Export points to the GRASS vector map.
	dbInstance.exportGrassAscii_points("sites", outmap="test", geom="geom", gid="gid")

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 3: Find the nearest features.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_3():
	outmap="test"
	print 'Calculating nearest features...'
	gcol_dist = "distance double precision"	# Column definition to store distances of the nearest feature.
	gcol_nrst = "nearest integer"		# Column definition to store ids of the nearest feature.
	gcol_updt = "dist,cat"			# The column names for query.
	gcol_curs = "distance,nearest"		# The column names for query.
	# Add new table to store the nearest neighbors and their distances procedure.
	g.run_command('v.db.addtable', map=outmap, quiet=True)
	g.run_command('v.db.addcol', map=outmap, columns=gcol_dist+','+gcol_nrst, quiet=True)
	g.run_command('v.distance', _from=outmap, to=outmap, dmin='1', upload=gcol_updt, column=gcol_curs, quiet=True)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 4: Feedback the results to the database.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_4(dbInstance):
	outmap="test"		# The name of GRASS vector map exported to.
	gcol_dist="distance"	# The name of the column for storing the distance of the nearest feature.
	gcol_nrst="nearest"	# The name of the column for storing the identifier of the nearest feature.
	table = "sites"		# The name of the table to update.
	pgcol_nkey="n_key"	# The name of the column to update with the identifier to the nearest feature.
	pgcol_ndist="n_dist"	# The name of the column to update with the distance to the nearest feature.
	# Get the number of points stored in GRASS vector map.
	n = mygrass.getPointsNum(outmap)
	# Create a progress bar object.
	widgets = ['UPDATE COLUMNS: ', Percentage(), ' ', Bar(marker=RotatingMarker()),' ', ETA(), ' ', FileTransferSpeed()]
	pbar = ProgressBar(widgets=widgets, maxval=n+1).start()
	for i in range(n):
		# Select a i_th feature from grass vector map, and get values of category, distance and identifier of the nearest feature. 
		attr=g.parse_command('v.db.select',map=outmap, flags='c',columns='cat,'+gcol_dist+','+gcol_nrst,where='cat='+str(i+1))
		cat=dict.keys(attr)[0].split("|")[0]	# The category number which responds to the gid.
		dst=dict.keys(attr)[0].split("|")[1]	# The distance to the nearest feature.
		npt=dict.keys(attr)[0].split("|")[2]	# The identifier of the nearest feature.
		# Generate keys-values pair for updating columns.
		keys={pgcol_ndist:str(dst),pgcol_nkey:str(npt)}
		# Generate "WHERE" keyword.
		where="gid="+str(cat)
		# Update the table.
		dbInstance.updatecol(table,keys,where)
		# Change the value of progress bar.
		pbar.update(i+1)

	pbar.finish()
	# commit changes
	dbInstance.connection.commit()
	# Remove Grass vector map exported from the database.
	g.run_command('g.remove',vect=outmap, quiet=True)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 5: Calculate the quantile of the distances of the nearest points.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_5(user, passwd, dbname):
	query = 'SELECT "n_dist" FROM "sites"'
	con = r.r_conPgsql(user, passwd, dbname)
	res = r.r_query(con, queryString=query)
	dat = r.r_fetch(res, maxrecord=-1)
	return r.r_summary(dat)

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 6: Construct buffer with the 3rd quantile of the nearest distances.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_6(dbInstance, Q3rd):
	print 'Constructing buffer with 3_rd quantile of nearest distances...'
	dbInstance.bufferFromSize("sites", str(Q3rd), "gid", "geom", "quBuff")
	dbInstance.connection.commit()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 7: Merge buffers
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_7(dbInstance):
	print 'Merge Buffers...'
	dbInstance.merge("sites","mBufferQu","quBuff")
	dbInstance.connection.commit()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 8: Query points on polygons and summarize values of sepecific columns.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_8(dbInstance):
	print 'Spatial query...'
	# Define query items.
	collist = []
	collist.append({'n_dist':'median'})
	collist.append({'n_dist':'average'})
	collist.append({'n_dist':'max'})
	collist.append({'n_dist':'min'})

	# Spatial Query for points on plygons.
	dbInstance.spatialQuery_pointsOnPolygon(
		points = "sites", 
		polygons = 'mBufferQu', 
		columnlist = collist, 
		pointGeom="geom", 
		polyGeom="geom", 
		pointId = "gid", 
		polyId = "gid")

	# Commit the results.
	dbInstance.connection.commit()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 9: Construct buffer with the nearest distances.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_9(dbInstance, q1st):
	print "Construct buffer..."
	table="sites"
	column = "buff_size"
	idcol = "gid"
	inGeom="geom"
	outGeom="buffer"

	# Create a column to store buffer size.
	# db.dropcol(table,outGeom)
	dbInstance.addcol(table,column,"numeric")

	# Use the first quantile for the sites which are isolated.
	dbInstance.cursor.execute('UPDATE "'+ table +'" SET ' + column +' = n_dist')
	keys={column:str(q1st)}
	where="pointsnum <= 2"
	dbInstance.updatecol(table, keys, where)
	dbInstance.connection.commit()

	# Construct buffer from column
	dbInstance.bufferFromColumn(table, column, idcol, inGeom,outGeom)
	dbInstance.connection.commit()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 10: Merge buffers and construct Operational Archaeological Units.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_10(dbInstance):
	print 'Merge Buffers...'
	dbInstance.merge("sites","OAU","buffer")
	dbInstance.dropTable("mBufferQu")
	dbInstance.connection.commit()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 11: Create a database instance.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_11(dbInstance,dbhost=grassdb_host,dbtype=grassdb_type,user=grassdb_user,password=grassdb_pass):
	print 'Connecting to database...'
	# Connect to GRASS Database.
	connectToGrassDb(dbhost,dbtype,user,password)

	table = "OAU"
	outmap = "buffer"
	geom = "geom"
	gid = "gid"

	# Export rings of polygons to GRASS GIS.
	#db.exportGrassAscii_ring(table, outmap, geom, gid)

	# Create a new table to store counts of raster values.
	table = "LanduseCount"
	coldict={"id":"integer",
		"ricefieldspoly":"integer",
		"otherfarmlands":"integer",
		"forest":"integer",
		"wasteLands":"integer",
		"buildingSites":"integer",
		"arterialhighway":"integer",
		"other":"integer",
		"riversandlakes":"integer",
		"seashore":"integer",
		"sea":"integer",
		"golffields":"integer"}

	collist=["id",
		"ricefieldspoly",
		"otherfarmlands",
		"forest",
		"wastelands",
		"buildingsites",
		"arterialhighway",
		"other",
		"riversandlakes",
		"seashore",
		"sea",
		"golffields"]

	dbInstance.createTable(table, coldict)
	dbInstance.connection.commit()

	# Name of the input raster map.
	rast="landuse"
	# get feature information about the polygons
	info = g.parse_command("v.info",flags="t",map=outmap,quiet=True)
	# get number of polygons
	num = int(info["areas"])

	# Create a progress bar object.
	widgets = ['Count raster values: ', Percentage(), ' ', Bar(marker=RotatingMarker()),' ', ETA(), ' ', FileTransferSpeed()]
	pbar = ProgressBar(widgets=widgets, maxval=num+1).start()

	for i in range(1,num+1):
		# Extract one feature from points set with cat value.
		g.run_command("v.extract",input=outmap,output="tmp",type="area",layer=1,new=-1,list=i,quiet=True,overwrite=True)
		# Add a new polygon table for storing a new value.
		g.run_command("v.db.addtable",map="tmp",columns="val int",quiet=True)  
		## Add a new polygon column for storing a new value.
		##g.run_command("v.db.addcol",map="tmp",columns="val int")                    
		# Set default value as 1.
		g.run_command("v.db.update",map="tmp",column="val",value=1,quiet=True)
		# Redefine geographic region for procedure.
		g.run_command("g.region",vect="tmp",quiet=True)
		# Convert vector map buffer to raster map buffer.
		g.run_command("v.to.rast",input="tmp",output="tmprast",use="val",overwrite=True,quiet=True)
		# Get values on the raster buffer.
		g.run_command("r.mapcalculator",amap="tmprast",bmap=rast,formula="A*B",outfile="tmprast2",overwrite=True,quiet=True)
		pix = g.parse_command("r.stats",flags="c",input="tmprast2",nv="",fs=",",quiet=True)
		# Create an array of values.
		vals = {1:0,2:0,5:0,6:0,7:0,9:0,10:0,11:0,14:0,15:0,16:0}
		for j in range(len(pix)):
			item = dict.keys(pix)[j].split(",")[0]
			if item != "":
				item = int(item)
				cnts = int(dict.keys(pix)[j].split(",")[1])
				vals[item] = cnts

		keylist = vals.keys()
	
		# Sort values.
		keylist.sort()
		svals = []
		svals.append(i)
		for k in keylist:
			svals.append(vals[k])

		# Insert values to database.
		db.insertRow(table, collist, svals)
		# Remove temporal features
		g.parse_command("g.remove",vect="tmp",rast="tmprast,tmprast2",quiet=True)
		# Set region with DEM.
		g.parse_command("g.region",rast=rast,quiet=True)
		pbar.update(i+1)

	pbar.finish()
	db.connection.commit()

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Step 12: Analysing data by using PCA.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
def step_12():
	table = '"LanduseCount"'
	qcols='"ricefieldspoly","otherfarmlands","forest","wastelands","buildingsites","arterialhighway","other","riversandlakes","seashore","sea","golffields"'
	
	query = "SELECT " + qcols + " FROM " + table
	# Connect to the database.
	con = r.r_conPgsql(user=pgsql_user, passwd=pgsql_pass, dbname=pgsql_name)
	# Build the query.
	res = r.r_query(con, queryString=query)
	# Fetch the dataset.
	dat = r.r_fetch(res, maxrecord=-1)
	# Analyse the dataset by Principal Component Analysis(PCA)
	# Package "FactoMineR" is required.
	pca = r.r_pca(dat)
	# Plot the result.
	r.r_pca_plot(pca,argAxes=[2,3],argChoix="ind")
	raw_input("Press Enter to continue...")
	r.r_pca_plot(pca,argAxes=[2,3],argChoix="var")
	raw_input("Press Enter to continue...")

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Main Flow.
# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
print 'Connecting to PostgreSQL Server...'
db = connectToPgsql(dbname=pgsql_name,
	srid=pgsql_srid,
	user=pgsql_user,
	password=pgsql_pass)

connectToGrassDb(dbhost=grassdb_host,dbtype=grassdb_type,user=grassdb_user,password=grassdb_pass)

'''
# Step 1: Add columns to the "sites" table.
step_1(dbInstance=db)

# Step 2: Export the result as GRASS standard ASCII format.
step_2(dbInstance=db,
	dbhost=grassdb_host,
	dbtype=grassdb_type,
	user=grassdb_user,
	password=grassdb_pass)

# Step 3: Find the nearest features.
step_3()

# Step 4: Feedback the results to the database.
step_4(dbInstance=db)
'''
# Step 5: Get quantile of the nearest distances.
smm = step_5(user=pgsql_user,
	passwd=pgsql_pass, 
	dbname=pgsql_name)

qu_min = float(smm[0].split(":")[1])	# Lower bound of the nearest distance.
qu_1st = float(smm[1].split(":")[1])	# The 1_st quantile of the nearest distance.
qu_med = float(smm[2].split(":")[1])	# Median of the nearest distance.
qu_men = float(smm[3].split(":")[1])	# Mean of the nearest distance.
qu_3rd = float(smm[4].split(":")[1])	# The 3_rd quantile of the nearest distance.
qu_max = float(smm[5].split(":")[1])	# Higher bound of the nearest distance.

'''
# Step 6: Constructing buffer with the 3rd quantile of the nearest distances.
step_6(dbInstance=db, Q3rd=qu_3rd)

# Step 7: Merge buffers.
step_7(dbInstance=db)
# Step 8: Query points on polygons and summarize values of sepecific columns.
step_8(dbInstance=db)

# Step 9: Constructing buffer with the nearest distances.
step_9(dbInstance=db, q1st=qu_1st)

# Step 10: Merge buffers and construct Operational Archaeological Units.
step_10(dbInstance=db)

# Step 11: Create a database instance.
step_11(dbInstance=db)
'''
# Step 12: Analysing data by using PCA.
step_12()


