#!/bin/bash
# After login to GRASS GIS session, run following commands on terminal.
# Also, you need to configre paths and database connection info.

# Remove existing database
dropdb miyagi
dropdb caa2012

# Create database with PostGIS template
createdb miyagi
createdb caa2012

# Apply spatial extension to the database.
psql -U yufujimoto -f '/usr/share/postgresql/9.1/contrib/postgis-2.0/postgis.sql' -d miyagi
# Insert information of spatial reference system to the database.
psql -U yufujimoto -f '/usr/share/postgresql/9.1/contrib/postgis-2.0/spatial_ref_sys.sql' -d miyagi
# Apply PostGIS raster extension to the database.
psql -U yufujimoto -f '/usr/share/postgresql/9.1/contrib/postgis-2.0/rtpostgis.sql' -d miyagi

#Import Shapefiles by using SQL documents.
psql miyagi -f  '/path/to/the/data/file/sites.sql'   
psql miyagi -f  '/path/to/the/data/file/tsunami.sql'

# Import raster datasets to GRASS raster map.
db.connect driver=pg database=host=localhost,dbname=caa2012
db.login driver=pg database=host=localhost,dbname=caa2012 user=username password=password
r.in.gdal input='/path/to/the/sql/data/landusage_csx.tif' output=landuse 
r.in.gdal input='/path/to/the/sql/data/elevation_csx.tiff' output=elev

